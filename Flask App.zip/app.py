from flask import Flask, request, json, render_template
import pickle
import pandas as pd
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import OneHotEncoder

app = Flask(__name__)

@app.route('/')
@app.route('/home')
def home_page():

    return render_template('home.html')

    #Resume is my home page

@app.route('/projects')
def general_projects_page():
    items = [
        {'name': 'Mushroom Classifier'},
        {'name': '2D Data Modeling'},
        {'name': '3D Data Modeling'}
    ]

    return render_template('projects.html', items=items)

    #Link to projects on github

@app.route('/model')
def model_page():
    return render_template('bio_model.html')

    #Allows user to select inputs for model

@app.route('/predict_api', methods = ['POST'])
def predict_api():
    model = pickle.load(open('pickle_model.sav', 'rb'))
    formJsonString = json.dumps(request.form)
    formJson = json.JSONDecoder().decode(formJsonString)
    formDataFrame = pd.read_json(json.JSONEncoder().encode([formJson]), orient='records')
    print(formDataFrame)

    numeric_attributes = ['Acres', 'Number_of_species']
    categorical_attributes_2 = ['State', 'Order', 'Family', 'Nativeness', 'Abundance', 'Longitude']

    numeric_pipeline = Pipeline([
        ('standard_scalar', StandardScaler())
    ])

    num_and_cat_pipeline_2 = ColumnTransformer([
        ('numeric', numeric_pipeline, numeric_attributes),
        ('categorical', OneHotEncoder(handle_unknown='ignore'), categorical_attributes_2),
    ])

    X_train = pd.read_csv('X_train.csv')
    X_train = num_and_cat_pipeline_2.fit_transform(X_train)
    encodedData = num_and_cat_pipeline_2.transform(formDataFrame)
    prediction = model.predict(encodedData)
    output = round(prediction[0], 4)

    return render_template('result.html', prediction=output)

    #returns result from inputs that the user gives