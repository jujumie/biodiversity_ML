import pandas as pd
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import OneHotEncoder
from sklearn.ensemble import GradientBoostingRegressor
import pickle

X_train = pd.read_csv('X_train.csv')
X_test = pd.read_csv('X_test.csv')
training = pd.read_csv('training.csv')
testing = pd.read_csv('testing.csv')

numeric_attributes = ['Acres', 'Number_of_species']

categorical_attributes_2 = ['State', 'Order', 'Family', 'Nativeness', 'Abundance', 'Longitude']

numeric_pipeline = Pipeline([
     ('standard_scalar', StandardScaler())
 ])

num_and_cat_pipeline_2 = ColumnTransformer([
    ('numeric', numeric_pipeline, numeric_attributes),
    ('categorical', OneHotEncoder(handle_unknown='ignore'), categorical_attributes_2),
 ])

X_train = num_and_cat_pipeline_2.fit_transform(X_train)

X_test = num_and_cat_pipeline_2.transform(X_test)

y_train = training[['species_richness']]

y_test = testing[['species_richness']]

y_train = numeric_pipeline.fit_transform(y_train)

y_test = numeric_pipeline.transform(y_test)

model = GradientBoostingRegressor(learning_rate=0.3, max_depth=3, n_estimators=360, random_state=42)

model.fit(X_train, y_train)

filename = 'pickle_model.sav'

pickle.dump(model, open(filename, 'wb'))